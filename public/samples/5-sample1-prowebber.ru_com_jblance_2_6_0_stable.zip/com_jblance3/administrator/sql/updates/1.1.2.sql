ALTER TABLE `#__jblance_project` ADD (`buyer_commission` float NOT NULL DEFAULT '0');
ALTER TABLE `#__jblance_project` ADD (`lancer_commission` float NOT NULL DEFAULT '0');
ALTER TABLE `#__jblance_project` ADD (`accept_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00');