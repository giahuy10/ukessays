ALTER TABLE `#__jblance_project` ADD (`metakey` TEXT);
ALTER TABLE `#__jblance_project` ADD (`metadesc` TEXT);