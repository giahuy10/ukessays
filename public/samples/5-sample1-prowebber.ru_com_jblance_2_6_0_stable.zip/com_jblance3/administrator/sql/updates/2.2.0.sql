ALTER TABLE `#__jblance_project` ADD (`profit_perproject` float NOT NULL DEFAULT '0');
ALTER TABLE `#__jblance_bid` ADD (`profit_perbid` float NOT NULL DEFAULT '0');
ALTER TABLE `#__jblance_service` ADD (`profit_perservice` float NOT NULL DEFAULT '0');