ALTER TABLE `#__jblance_project` MODIFY COLUMN `id_category` VARCHAR(250) NOT NULL;
ALTER TABLE `#__jblance_user` MODIFY COLUMN `id_category` VARCHAR(250) NOT NULL;