ALTER TABLE `#__jblance_portfolio` ADD (`attachment2` VARCHAR(255) NOT NULL);
ALTER TABLE `#__jblance_portfolio` ADD (`attachment3` VARCHAR(255) NOT NULL);
ALTER TABLE `#__jblance_portfolio` ADD (`attachment4` VARCHAR(255) NOT NULL);
ALTER TABLE `#__jblance_portfolio` ADD (`attachment5` VARCHAR(255) NOT NULL);
ALTER TABLE `#__jblance_portfolio` CHANGE `attachment` `attachment1` VARCHAR(255) NOT NULL;