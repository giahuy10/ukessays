ALTER TABLE `#__jblance_category` ADD (`category_image` text NOT NULL);
